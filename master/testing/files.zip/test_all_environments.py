"""
UNIFIED TEST RUNNER
Run your agent across ALL difficulty levels and seeds.

Usage:
    python test_all_environments.py

This will:
1. Test on LIGHT (4 nodes, easy)
2. Test on SANDBOX (6 nodes, baseline)
3. Test on MEDIUM (8 nodes, harder)
4. Test on HARD (12 nodes, very hard)
5. Test on EXTREME (16 nodes, stress test)

Compare performance across all difficulties to see:
- Does it generalize?
- Where does it struggle?
- Are thresholds tuned well?
"""

from sandbox_env import make_sandbox_env
from test_env_light import make_light_env
from test_env_medium import make_medium_env
from test_env_hard import make_hard_env
from test_env_extreme import make_extreme_env

# Import your agent here
# from health_aware_agent import HealthAwareAgent


def run_agent_on_env(env, agent, env_name: str, seeds: list = None, debug: bool = False):
    """
    Run agent on given environment for multiple seeds.
    
    Args:
        env: Environment factory function (e.g., make_sandbox_env)
        agent: Agent class (e.g., HealthAwareAgent)
        env_name: Name for logging (e.g., "SANDBOX")
        seeds: List of seeds to test (default: 0-4)
        debug: Whether to expose ground truth
    
    Returns:
        dict with results
    """
    if seeds is None:
        seeds = list(range(5))
    
    results = {
        "env_name": env_name,
        "episodes": [],
        "avg_completion": 0.0,
        "avg_failed": 0.0,
        "avg_reward": 0.0,
    }
    
    for seed in seeds:
        environment = env(seed=seed, debug=debug)
        ag = agent(n_nodes=environment.n_nodes, 
                   node_capacity=environment.node_capacity)
        
        obs = environment.reset()
        ag.reset()
        
        total_reward = 0.0
        for step in range(environment.episode_length):
            actions = ag.act(obs)
            obs, reward, done, info = environment.step(actions)
            ag.update(obs, reward, done, info)
            total_reward += reward
            
            if done:
                break
        
        log = environment.get_episode_log()
        completed = log["completed_count"]
        failed = log["failed_count"]
        total = completed + failed
        completion_rate = completed / total if total > 0 else 0.0
        
        results["episodes"].append({
            "seed": seed,
            "completed": completed,
            "failed": failed,
            "completion_rate": completion_rate,
            "total_reward": total_reward,
        })
    
    # Compute averages
    if results["episodes"]:
        avg_completion = sum(e["completion_rate"] for e in results["episodes"]) / len(results["episodes"])
        avg_failed = sum(e["failed"] for e in results["episodes"]) / len(results["episodes"])
        avg_reward = sum(e["total_reward"] for e in results["episodes"]) / len(results["episodes"])
        
        results["avg_completion"] = avg_completion
        results["avg_failed"] = avg_failed
        results["avg_reward"] = avg_reward
    
    return results


def print_results_table(all_results: list):
    """Print results in a nice table."""
    print("\n" + "="*80)
    print("TEST RESULTS: Agent Performance Across Difficulties")
    print("="*80)
    print(f"{'Environment':<15} {'Nodes':<8} {'Avg Completion':<18} {'Avg Failed':<12} {'Avg Reward':<12}")
    print("-"*80)
    
    for result in all_results:
        env_name = result["env_name"]
        episodes = result["episodes"]
        if episodes:
            first_ep = episodes[0]
            # Infer node count from environment (rough guess from name)
            if "LIGHT" in env_name:
                nodes = 4
            elif "SANDBOX" in env_name:
                nodes = 6
            elif "MEDIUM" in env_name:
                nodes = 8
            elif "HARD" in env_name:
                nodes = 12
            elif "EXTREME" in env_name:
                nodes = 16
            else:
                nodes = "?"
            
            print(f"{env_name:<15} {str(nodes):<8} {result['avg_completion']:.1%}{' '*11} "
                  f"{result['avg_failed']:<12.1f} {result['avg_reward']:<12.1f}")
    
    print("="*80)


def print_detailed_results(all_results: list):
    """Print detailed per-seed results."""
    print("\nDETAILED RESULTS (Per Seed):")
    print("="*80)
    
    for result in all_results:
        print(f"\n{result['env_name']}:")
        print(f"  {'Seed':<6} {'Completed':<12} {'Failed':<10} {'Completion':<15} {'Reward':<10}")
        print("-"*60)
        
        for ep in result["episodes"]:
            seed = ep["seed"]
            completed = ep["completed"]
            failed = ep["failed"]
            completion_rate = ep["completion_rate"]
            reward = ep["total_reward"]
            
            print(f"  {seed:<6} {completed:<12} {failed:<10} {completion_rate:>6.1%}{' '*7} {reward:>7.1f}")


def main():
    """
    Run full test suite.
    
    NOTE: Uncomment the import below once you have your agent.
    """
    
    print("Cluster Agent - Full Environment Test Suite")
    print("="*80)
    
    # NOTE: Uncomment this line once you have your agent implemented
    # from health_aware_agent import HealthAwareAgent
    
    # TEMPORARY: Show what to do
    print("\n⚠️  How to use this test suite:\n")
    print("1. Implement your agent: health_aware_agent.py")
    print("2. Uncomment the import line (around line 110):")
    print("   from health_aware_agent import HealthAwareAgent\n")
    print("3. Uncomment the test code below (around line 130)\n")
    print("4. Run: python test_all_environments.py\n")
    
    print("="*80)
    print("\nExample output (after implementation):\n")
    print("TEST RESULTS: Agent Performance Across Difficulties")
    print("-"*80)
    print("Environment      Nodes   Avg Completion   Avg Failed   Avg Reward")
    print("-"*80)
    print("LIGHT            4       85.0%            1.5          17.5")
    print("SANDBOX          6       80.0%            2.5          15.0")
    print("MEDIUM           8       75.0%            3.5          12.5")
    print("HARD             12      70.0%            4.5          10.0")
    print("EXTREME          16      60.0%            6.5          3.0")
    print("="*80)
    
    print("\nTest Results Interpretation:")
    print("  - Completion rate: Higher is better (>75% = good)")
    print("  - Avg failed: Lower is better (<4 = good)")
    print("  - Avg reward: Higher is better (>10 = good)")
    print("\nIf scores drop significantly on harder environments:")
    print("  → Your agent may have hardcoded thresholds (not generalizing)")
    print("  → Or detection logic is too sensitive to specific node counts")
    print("  → Try tuning: health thresholds, latency penalties, error rate thresholds")
    
    
    """
    UNCOMMENT THIS SECTION ONCE YOU HAVE YOUR AGENT:
    
    ============================================================================
    
    # Create results list
    all_results = []
    
    # Test on all difficulties
    print("\nRunning tests...\n")
    
    result = run_agent_on_env(make_light_env, HealthAwareAgent, 
                             "LIGHT (4 nodes)", seeds=[0, 1, 2], debug=False)
    all_results.append(result)
    print(f"✓ LIGHT completed: {result['avg_completion']:.1%}")
    
    result = run_agent_on_env(make_sandbox_env, HealthAwareAgent,
                             "SANDBOX (6 nodes)", seeds=[0, 1, 2], debug=False)
    all_results.append(result)
    print(f"✓ SANDBOX completed: {result['avg_completion']:.1%}")
    
    result = run_agent_on_env(make_medium_env, HealthAwareAgent,
                             "MEDIUM (8 nodes)", seeds=[0, 1, 2], debug=False)
    all_results.append(result)
    print(f"✓ MEDIUM completed: {result['avg_completion']:.1%}")
    
    result = run_agent_on_env(make_hard_env, HealthAwareAgent,
                             "HARD (12 nodes)", seeds=[0, 1, 2], debug=False)
    all_results.append(result)
    print(f"✓ HARD completed: {result['avg_completion']:.1%}")
    
    result = run_agent_on_env(make_extreme_env, HealthAwareAgent,
                             "EXTREME (16 nodes)", seeds=[0, 1, 2], debug=False)
    all_results.append(result)
    print(f"✓ EXTREME completed: {result['avg_completion']:.1%}")
    
    # Print results
    print_results_table(all_results)
    print_detailed_results(all_results)
    
    # Summary
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    avg_across_all = sum(r["avg_completion"] for r in all_results) / len(all_results)
    print(f"Average completion rate across all environments: {avg_across_all:.1%}")
    
    if avg_across_all > 0.75:
        print("✓ Excellent generalization! Agent handles various configs well.")
    elif avg_across_all > 0.65:
        print("⚠ Good generalization. Could improve on harder environments.")
    else:
        print("✗ Agent struggles on harder environments. Review thresholds.")
    
    ============================================================================
    """


if __name__ == "__main__":
    main()
